package br.com.lojax.lojax;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LojaxApplication {

	public static void main(String[] args) {
		SpringApplication.run(LojaxApplication.class, args);
	}

}
