package br.com.lojax.lojax;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LojaxApplicationTests {

	@Test
	void contextLoads() {
	}

}
